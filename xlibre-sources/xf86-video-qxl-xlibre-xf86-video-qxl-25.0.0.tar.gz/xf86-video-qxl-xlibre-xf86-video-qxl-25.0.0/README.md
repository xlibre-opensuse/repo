The QXL virtual GPU is found in the Red Hat Enterprise
Virtualisation system, and also in the spice project.

The primary development code repository can be found at:

  https://github.com/X11Libre/xf86-video-qxl

Please submit bug reports and requests to merge patches there.
