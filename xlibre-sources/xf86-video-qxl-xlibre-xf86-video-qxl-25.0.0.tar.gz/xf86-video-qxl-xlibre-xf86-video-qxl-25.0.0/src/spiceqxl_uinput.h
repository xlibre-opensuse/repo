#ifndef SPICEQXL_UINPUT_H
#define SPICEQXL_UINPUT_H

#include "qxl.h"

void spiceqxl_uinput_init(qxl_screen_t *qxl);
void spiceqxl_uinput_watch(qxl_screen_t *qxl, Bool on);

#endif
