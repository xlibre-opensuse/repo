#ifndef SPICEQXL_VDAGENT_H
#define SPICEQXL_VDAGENT_H

#include "qxl.h"

void spiceqxl_vdagent_init(qxl_screen_t *qxl);

#endif
