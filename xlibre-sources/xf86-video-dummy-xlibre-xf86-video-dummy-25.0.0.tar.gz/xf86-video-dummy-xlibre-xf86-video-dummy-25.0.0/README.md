xf86-video-dummy - virtual/offscreen frame buffer driver for the XLibre X server
------------------------------------------------------------------------------

The primary development code repository can be found at:

  https://github.com/X11Libre/xf86-video-dummy

Please submit bug reports and requests to merge patches there.
