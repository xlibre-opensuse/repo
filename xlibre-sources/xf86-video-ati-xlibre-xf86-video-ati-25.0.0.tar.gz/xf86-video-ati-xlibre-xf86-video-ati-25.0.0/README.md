xf86-video-ati - Xorg driver for ATI/AMD Radeon GPUs using the radeon kernel driver
===================================================================================

Questions regarding this software should be directed at the
[amd-gfx mailing list](https://lists.freedesktop.org/mailman/listinfo/amd-gfx).

[main development code repository](https://github.com/X11Libre/xf86-video-ati)

Please submit bug reports there and use merge requests for patch submission.
