/***********************************************************

Copyright 1987, 1998  The Open Group

Permission to use, copy, modify, distribute, and sell this software and its
documentation for any purpose is hereby granted without fee, provided that
the above copyright notice appear in all copies and that both that
copyright notice and this permission notice appear in supporting
documentation.

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
OPEN GROUP BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

Except as contained in this notice, the name of The Open Group shall not be
used in advertising or otherwise to promote the sale, use or other dealings
in this Software without prior written authorization from The Open Group.

Copyright 1987 by Digital Equipment Corporation, Maynard, Massachusetts.

                        All Rights Reserved

Permission to use, copy, modify, and distribute this software and its
documentation for any purpose and without fee is hereby granted,
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in
supporting documentation, and that the name of Digital not be
used in advertising or publicity pertaining to distribution of the
software without specific, written prior permission.

DIGITAL DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL
DIGITAL BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
SOFTWARE.

******************************************************************/

#include <dix-config.h>

#include <X11/X.h>
#include <X11/Xmd.h>

#include "dix/cursor_priv.h"
#include "dix/dix_priv.h"
#include "dix/screenint_priv.h"
#include "os/bug_priv.h"

#include "servermd.h"
#include "scrnintstr.h"
#include "dixstruct.h"
#include "cursorstr.h"
#include "dixfontstr.h"
#include "opaque.h"
#include "inputstr.h"
#include "xace.h"

typedef struct _GlyphShare {
    FontPtr font;
    unsigned short sourceChar;
    unsigned short maskChar;
    CursorBitsPtr bits;
    struct _GlyphShare *next;
} GlyphShare, *GlyphSharePtr;

static GlyphSharePtr sharedGlyphs = (GlyphSharePtr) NULL;

static CARD32 cursorSerial;

static void
FreeCursorBits(CursorBitsPtr bits)
{
    if (--bits->refcnt > 0)
        return;
    free(bits->source);
    free(bits->mask);
    free(bits->argb);
    dixFiniPrivates(bits, PRIVATE_CURSOR_BITS);
    if (bits->refcnt == 0) {
        GlyphSharePtr *prev, this;

        for (prev = &sharedGlyphs;
             (this = *prev) && (this->bits != bits); prev = &this->next);
        if (this) {
            *prev = this->next;
            CloseFont(this->font, (Font) 0);
            free(this);
        }
        free(bits);
    }
}

/**
 * To be called indirectly by DeleteResource; must use exactly two args.
 *
 *  \param value must conform to DeleteType
 */
int
FreeCursor(void *value, XID cid)
{
    if (!value)
        return Success;

    CursorPtr pCurs = (CursorPtr) value;
    DeviceIntPtr pDev = NULL;   /* unused anyway */

    UnrefCursor(pCurs);
    if (CursorRefCount(pCurs) != 0)
        return Success;

    BUG_WARN(CursorRefCount(pCurs) < 0);

    DIX_FOR_EACH_SCREEN({
        if (walkScreen->UnrealizeCursor)
            walkScreen->UnrealizeCursor(pDev, walkScreen, pCurs);
    });

    FreeCursorBits(pCurs->bits);
    dixFiniPrivates(pCurs, PRIVATE_CURSOR);
    free(pCurs);
    return Success;
}

CursorPtr
RefCursor(CursorPtr cursor)
{
    if (cursor)
        cursor->refcnt++;
    return cursor;
}

CursorPtr
UnrefCursor(CursorPtr cursor)
{
    if (cursor)
        cursor->refcnt--;
    return cursor;
}

int
CursorRefCount(ConstCursorPtr cursor)
{
    return cursor ? cursor->refcnt : 0;
}


/*
 * We check for empty cursors so that we won't have to display them
 */
static void
CheckForEmptyMask(CursorBitsPtr bits)
{
    unsigned char *msk = bits->mask;
    int n = BitmapBytePad(bits->width) * bits->height;

    bits->emptyMask = FALSE;
    while (n--)
        if (*(msk++) != 0)
            return;
    if (bits->argb) {
        CARD32 *argb = bits->argb;

        n = bits->width * bits->height;
        while (n--)
            if (*argb++ & 0xff000000)
                return;
    }
    bits->emptyMask = TRUE;
}

/**
 * realize the cursor for every screen. Do not change the refcnt, this will be
 * changed when ChangeToCursor actually changes the sprite.
 *
 * @return Success if all cursors realize on all screens, BadAlloc if realize
 * failed for a device on a given screen.
 */
static int
RealizeCursorAllScreens(CursorPtr pCurs)
{
    DIX_FOR_EACH_SCREEN({
        for (DeviceIntPtr pDev = inputInfo.devices; pDev; pDev = pDev->next) {
            if (DevHasCursor(pDev)) {
                if (!(*walkScreen->RealizeCursor) (pDev, walkScreen, pCurs)) {
                    /* Realize failed for device pDev on screen walkScreen.
                     * We have to assume that for all devices before, realize
                     * worked. We need to rollback all devices so far on the
                     * current screen and then all devices on previous
                     * screens.
                     */
                    DeviceIntPtr pDevIt = inputInfo.devices;    /*dev iterator */

                    while (pDevIt && pDevIt != pDev) {
                        if (DevHasCursor(pDevIt) && walkScreen->UnrealizeCursor)
                            walkScreen->UnrealizeCursor(pDevIt, walkScreen, pCurs);
                        pDevIt = pDevIt->next;
                    }
                    while (--walkScreenIdx>= 0) {
                        walkScreen = dixGetScreenPtr(walkScreenIdx);
                        /* now unrealize all devices on previous screens */
                        pDevIt = inputInfo.devices;
                        while (pDevIt) {
                            if (DevHasCursor(pDevIt) && walkScreen->UnrealizeCursor)
                                walkScreen->UnrealizeCursor(pDevIt, walkScreen, pCurs);
                            pDevIt = pDevIt->next;
                        }
                        if (walkScreen->UnrealizeCursor)
                            walkScreen->UnrealizeCursor(pDev, walkScreen, pCurs);
                    }
                    return BadAlloc;
                }
            }
        }
    });

    return Success;
}

/**
 * does nothing about the resource table, just creates the data structure.
 *
 * Takes ownership of \p psrcbits, \p pmaskbits, and \p argb -- all three
 * are freed on error, the caller must not free them after calling this.
 *
 *  \param psrcbits  server-defined padding
 *  \param pmaskbits server-defined padding
 *  \param argb      no padding
 */
int
AllocARGBCursor(unsigned char *psrcbits, unsigned char *pmaskbits,
                CARD32 *argb, CursorMetricPtr cm,
                unsigned short foreRed, unsigned short foreGreen, unsigned short foreBlue,
                unsigned short backRed, unsigned short backGreen, unsigned short backBlue,
                CursorPtr *ppCurs, ClientPtr client, XID cid)
{
    *ppCurs = NULL;

    CursorPtr pCurs = (CursorPtr) calloc(CURSOR_REC_SIZE + CURSOR_BITS_SIZE, 1);
    if (!pCurs) {
        free(psrcbits);
        free(pmaskbits);
        free(argb);
        return BadAlloc;
    }

    CursorBitsPtr bits = (CursorBitsPtr) ((char *) pCurs + CURSOR_REC_SIZE);
    dixInitPrivates(pCurs, pCurs + 1, PRIVATE_CURSOR);
    dixInitPrivates(bits, bits + 1, PRIVATE_CURSOR_BITS)
        bits->source = psrcbits;
    bits->mask = pmaskbits;
    bits->argb = argb;
    bits->width = cm->width;
    bits->height = cm->height;
    bits->xhot = cm->xhot;
    bits->yhot = cm->yhot;
    pCurs->refcnt = 1;
    bits->refcnt = -1;
    CheckForEmptyMask(bits);
    pCurs->bits = bits;
    pCurs->serialNumber = ++cursorSerial;
    pCurs->name = None;

    pCurs->foreRed = foreRed;
    pCurs->foreGreen = foreGreen;
    pCurs->foreBlue = foreBlue;

    pCurs->backRed = backRed;
    pCurs->backGreen = backGreen;
    pCurs->backBlue = backBlue;

    pCurs->id = cid;

    /* security creation/labeling check */
    int rc = XaceHookResourceAccess(client, cid, X11_RESTYPE_CURSOR,
                  pCurs, X11_RESTYPE_NONE, NULL, DixCreateAccess);
    if (rc != Success)
        goto error;

    rc = RealizeCursorAllScreens(pCurs);
    if (rc != Success)
        goto error;

    *ppCurs = pCurs;

    if (argb) {
        size_t size = bits->width * bits->height;

        for (size_t i = 0; i < size; i++) {
            if ((argb[i] & 0xff000000) == 0 && (argb[i] & 0xffffff) != 0) {
                /* ARGB data doesn't seem pre-multiplied, fix it */
                for (size_t j = 0; j < size; j++) {
                    CARD32 a, ar, ag, ab;

                    a = argb[j] >> 24;
                    ar = a * ((argb[j] >> 16) & 0xff) / 0xff;
                    ag = a * ((argb[j] >> 8) & 0xff) / 0xff;
                    ab = a * (argb[j] & 0xff) / 0xff;

                    argb[j] = a << 24 | ar << 16 | ag << 8 | ab;
                }

                break;
            }
        }
    }

    return Success;

 error:
    FreeCursorBits(bits);
    dixFiniPrivates(pCurs, PRIVATE_CURSOR);
    free(pCurs);

    return rc;
}

int
AllocGlyphCursor(Font source, unsigned short sourceChar, Font mask, unsigned short maskChar,
                 unsigned short foreRed, unsigned short foreGreen, unsigned short foreBlue,
                 unsigned short backRed, unsigned short backGreen, unsigned short backBlue,
                 CursorPtr *ppCurs, ClientPtr client, XID cid)
{
    FontPtr sourcefont;
    int rc = dixLookupResourceByType((void **) &sourcefont, source, X11_RESTYPE_FONT,
                                 client, DixUseAccess);
    if ((rc != Success) || (!sourcefont)) {
        client->errorValue = source;
        return rc;
    }

    FontPtr maskfont;
    rc = dixLookupResourceByType((void **) &maskfont, mask, X11_RESTYPE_FONT, client,
                                 DixUseAccess);
    if (rc != Success && mask != None) {
        client->errorValue = mask;
        return rc;
    }

    GlyphSharePtr pShare;
    if (sourcefont != maskfont)
        pShare = (GlyphSharePtr) NULL;
    else {
        for (pShare = sharedGlyphs;
             pShare &&
             ((pShare->font != sourcefont) ||
              (pShare->sourceChar != sourceChar) ||
              (pShare->maskChar != maskChar)); pShare = pShare->next);
    }

    CursorPtr pCurs;
    CursorBitsPtr bits;
    if (pShare) {
        pCurs = (CursorPtr) calloc(CURSOR_REC_SIZE, 1);
        if (!pCurs)
            return BadAlloc;
        dixInitPrivates(pCurs, pCurs + 1, PRIVATE_CURSOR);
        bits = pShare->bits;
        bits->refcnt++;
    }
    else {
        CursorMetricRec cm;
        if (!CursorMetricsFromGlyph(sourcefont, sourceChar, &cm)) {
            client->errorValue = sourceChar;
            return BadValue;
        }

        unsigned char *mskbits;
        if (!maskfont) {
            size_t n = BitmapBytePad(cm.width) * (long) cm.height;
            mskbits = calloc(1, n);
            if (!mskbits)
                return BadAlloc;
            memset(mskbits, 0xFF, n);
        }
        else {
            if (!CursorMetricsFromGlyph(maskfont, maskChar, &cm)) {
                client->errorValue = maskChar;
                return BadValue;
            }
            if ((rc = ServerBitsFromGlyph(maskfont, maskChar, &cm, &mskbits)))
                return rc;
        }

        unsigned char *srcbits;
        if ((rc = ServerBitsFromGlyph(sourcefont, sourceChar, &cm, &srcbits))) {
            free(mskbits);
            return rc;
        }
        if (sourcefont != maskfont) {
            pCurs = (CursorPtr) calloc(CURSOR_REC_SIZE + CURSOR_BITS_SIZE, 1);
            if (pCurs)
                bits = (CursorBitsPtr) ((char *) pCurs + CURSOR_REC_SIZE);
            else
                bits = (CursorBitsPtr) NULL;
        }
        else {
            pCurs = (CursorPtr) calloc(CURSOR_REC_SIZE, 1);
            if (pCurs)
                bits = (CursorBitsPtr) calloc(CURSOR_BITS_SIZE, 1);
            else
                bits = (CursorBitsPtr) NULL;
        }
        if (!bits) {
            free(pCurs);
            free(mskbits);
            free(srcbits);
            return BadAlloc;
        }
        dixInitPrivates(pCurs, pCurs + 1, PRIVATE_CURSOR);
        dixInitPrivates(bits, bits + 1, PRIVATE_CURSOR_BITS);
        bits->source = srcbits;
        bits->mask = mskbits;
        bits->argb = 0;
        bits->width = cm.width;
        bits->height = cm.height;
        bits->xhot = cm.xhot;
        bits->yhot = cm.yhot;
        if (sourcefont != maskfont)
            bits->refcnt = -1;
        else {
            bits->refcnt = 1;
            pShare = calloc(1, sizeof(GlyphShare));
            if (!pShare) {
                FreeCursorBits(bits);
                return BadAlloc;
            }
            pShare->font = sourcefont;
            sourcefont->refcnt++;
            pShare->sourceChar = sourceChar;
            pShare->maskChar = maskChar;
            pShare->bits = bits;
            pShare->next = sharedGlyphs;
            sharedGlyphs = pShare;
        }
    }

    CheckForEmptyMask(bits);
    pCurs->bits = bits;
    pCurs->refcnt = 1;
    pCurs->serialNumber = ++cursorSerial;
    pCurs->name = None;

    pCurs->foreRed = foreRed;
    pCurs->foreGreen = foreGreen;
    pCurs->foreBlue = foreBlue;

    pCurs->backRed = backRed;
    pCurs->backGreen = backGreen;
    pCurs->backBlue = backBlue;

    pCurs->id = cid;

    /* security creation/labeling check */
    rc = XaceHookResourceAccess(client, cid, X11_RESTYPE_CURSOR,
                  pCurs, X11_RESTYPE_NONE, NULL, DixCreateAccess);
    if (rc != Success)
        goto error;

    rc = RealizeCursorAllScreens(pCurs);
    if (rc != Success)
        goto error;

    *ppCurs = pCurs;
    return Success;

 error:
    FreeCursorBits(bits);
    dixFiniPrivates(pCurs, PRIVATE_CURSOR);
    free(pCurs);

    return rc;
}

/** CreateRootCursor
 *
 * look up the name of a font
 * open the font
 * add the font to the resource table
 * make a cursor from the glyphs
 * add the cursor to the resource table
 *************************************************************/

CursorPtr
CreateRootCursor(void)
{
    const char defaultCursorFont[] = "cursor";

    XID fontID = dixAllocServerXID();
    int err = OpenFont(serverClient, fontID, FontLoadAll | FontOpenSync,
                   (unsigned) strlen(defaultCursorFont), defaultCursorFont);
    if (err != Success)
        return NullCursor;

    FontPtr cursorfont;
    err = dixLookupResourceByType((void **) &cursorfont, fontID, X11_RESTYPE_FONT,
                                  serverClient, DixReadAccess);
    if (err != Success)
        return NullCursor;

    CursorPtr curs;
    if (AllocGlyphCursor(fontID, 0, fontID, 1, 0, 0, 0, (unsigned short)~0U, (unsigned short)~0U, (unsigned short)~0U,
                         &curs, serverClient, (XID) 0) != Success)
        return NullCursor;

    if (!AddResource(dixAllocServerXID(), X11_RESTYPE_CURSOR, (void *) curs))
        return NullCursor;

    return curs;
}
